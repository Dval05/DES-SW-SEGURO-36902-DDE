# Informe unificado

## Contenido

- `Informe_Unificado.tex`: documento consolidado, basado en el informe principal y enriquecido con material técnico útil del informe AUTH_STEGO.
- `imagenes/`: figuras y evidencias del informe principal.
- `openapi/`: contratos OpenAPI de AUTH y STEGO aportados por el informe complementario.
- `documentos_fuente/`: copias de las dos fuentes originales para trazabilidad.

Para compilar, use pdfLaTeX (dos pasadas para actualizar índice y referencias) desde esta carpeta. El documento requiere los paquetes indicados en su preámbulo y los archivos de `imagenes/`.

## Aportes relevantes del informe AUTH_STEGO

1. **Contratos OpenAPI entregables:** incluye `auth.openapi.yaml` y `stego.openapi.yaml`, que complementan Swagger en ejecución y permiten inspeccionar rutas y esquemas fuera del entorno levantado.
2. **Más detalle sobre JWT:** explica la estructura Base64URL, la separación entre firma y cifrado, la lista de validaciones de claims, la distribución de clave pública y privada y la decisión de no usar roles del token como autorización vigente.
3. **Integración entre servicios:** concreta `x-service-token`, `x-request-id`, la decisión específica por acción y la denegación por defecto ante errores o indisponibilidad.
4. **Independencia operativa y límites de responsabilidad:** aclara que PostgreSQL es infraestructura de AUTH y que la independencia de despliegue no elimina la dependencia funcional de STEGO respecto de AUTH.
5. **Modelo e integridad:** amplía la explicación de las entidades, campos de sesión y auditoría, claves foráneas, unicidad e inicialización por migraciones.
6. **Detalle experimental:** describe extracción de LSB, variables estadísticas y límites de falsos positivos y negativos; refuerza la interpretación prudente del score.
7. **Riesgos y demostración:** desarrolla controles de carga, exposición de claves, IDOR, auditoría, persistencia y pasos de sustentación.

## Criterios de unificación y discrepancias observadas

- Se conserva como base la estructura y evidencia del informe principal: contiene las capturas de Postman, Newman, pruebas previas al commit, integración, entrega y consultas reales.
- Se integraron explicaciones complementarias de arquitectura, JWT, decisión entre servicios y contratos OpenAPI. Los contratos YAML también se incluyen como artefactos en `openapi/`.
- **Regla del detector:** las fuentes no coinciden. El principal condiciona la clase `sospechoso` a un score alto, una comparación con el segundo plano y un límite de chi-cuadrado; el complementario usa una regla simplificada basada únicamente en el score. La versión unificada conserva la regla del principal, porque es la que describe con mayor detalle el control implementado. No se mezclaron los resultados experimentales del complementario que parten de la regla simplificada.
- **Valores experimentales:** aparecen puntajes ligeramente distintos para la muestra LSB aleatoria (por ejemplo, 0.997958 en el principal y 0.997714 en el complementario). Se retienen los valores y capturas del principal; conviene cotejarlos con una corrida común del repositorio antes de presentarlos como una única medición.
- **Migraciones:** los informes mencionan nombres/fechas distintos de migración inicial y de alineación de esquema. Se conserva la narrativa del principal; verificar los nombres contra el árbol de código entregado si se busca que el documento describa una única versión exacta.
- **Exposición de STEGO:** el documento principal identifica HTTP local y el complementario advierte que una publicación fuera de loopback requiere HTTPS. Se mantiene la limitación en la sección de riesgos y despliegue, sin presentar la configuración académica local como apta para exposición externa.

Los ZIP originales no se modificaron.
